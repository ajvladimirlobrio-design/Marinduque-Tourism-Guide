
/* Get the required HTML elements */
const searchInput = document.getElementById("searchInput");
const filterButtons = document.querySelectorAll(".filter-btn");
const destinationCards = document.querySelectorAll(".destination-card");
const resultCount = document.getElementById("resultCount");
const noResults = document.getElementById("noResults");

/* Store the selected category */
let selectedCategory = "All";

/* Filter the destination cards */
function filterDestinations() {
    const searchText = searchInput.value.trim().toLowerCase();
    let visibleCount = 0;

    destinationCards.forEach(function (card) {
        const cardText = card.textContent.toLowerCase();
        const cardCategory = card.dataset.category;

        const matchesSearch = cardText.includes(searchText);

        const matchesCategory =
            selectedCategory === "All" ||
            cardCategory === selectedCategory;

        const shouldShow = matchesSearch && matchesCategory;

        card.hidden = !shouldShow;

        if (shouldShow) {
            visibleCount++;
        }
    });

    /* Update the destination count */
    resultCount.textContent =
        visibleCount +
        (visibleCount === 1
            ? " destination found"
            : " destinations found");

    /* Show the message when no cards match */
    noResults.hidden = visibleCount !== 0;
}

/* Listen for search input */
searchInput.addEventListener("input", filterDestinations);

/* Listen for category button clicks */
filterButtons.forEach(function (button) {
    button.addEventListener("click", function () {
        selectedCategory = button.dataset.category;

        /* Update the active button and accessibility state */
        filterButtons.forEach(function (filterButton) {
            const isActive = filterButton === button;

            filterButton.classList.toggle("active", isActive);
            filterButton.setAttribute("aria-pressed", String(isActive));
        });

        filterDestinations();
    });
});

/* Display all destinations on page load */
filterDestinations();
