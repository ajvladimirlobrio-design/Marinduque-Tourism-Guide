Task 1 — Sector Selection

Project Name: Marinduque Tourism Guide

Innovation Sector: Tourism & Cultural Innovation

Local Challenge: Tourists and other visitors may have difficulty finding information about tourist destinations and cultural attractions in Marinduque in one convenient place.

Target Users: Tourists, local residents, and students who want to discover destinations in Marinduque.

Proposed Solution: Develop a responsive, single-page tourism guide that presents selected destinations with short descriptions and simple browsing tools.

Key Features:

1. Destination cards containing the destination name, category, and description.
2. A search box that allows users to find destinations by keyword.
3. Category filter buttons for Beach, Nature, and Culture.

Scope: A frontend prototype built with HTML, CSS, and JavaScript. The project will use demonstration content and will not require a backend, database, authentication, or external APIs.

Task 2 — Zero-Shot Prompting

Objective:

To observe the initial webpage generated from a simple prompt without examples or detailed constraints.

Exact Prompt:

«Create a simple, responsive webpage called "Marinduque Tourism Guide" that helps tourists discover destinations in Marinduque. Include destination cards, a search box, and category filter buttons. Use HTML, CSS, and JavaScript.»

Actual Copilot Output:

AI tool used: ChatGPT

Saved output: "outputs/task2-zero-shot-index.html"

The actual generated HTML, CSS, and JavaScript are saved in the referenced output file.

What Worked:

After testing, all the features works perfectly.

What Needs Improvement:

After testing, the design need to be more realistic.

Next Action / Verification:

I open the webpage and the test destination cards, search box, category buttons, and mobile or tablet layout works perfectly.

Task 3 — Structured Prompt

Objective:

To improve the relevance and completeness of the webpage by specifying the role, task, context, constraints, expected output, and acceptance criteria.

Exact Prompt:

Role: Act as an experienced frontend web developer.

Task: Improve the Marinduque Tourism Guide webpage generated in Task 2.

Context: The project belongs to the Tourism & Cultural Innovation sector. It helps tourists, local residents, and students discover tourist destinations and cultural attractions in Marinduque, Philippines.

Constraints: Use semantic HTML, CSS, and vanilla JavaScript only. Do not use external frameworks, backend services, databases, authentication, or external APIs. Keep the project as a single-page responsive frontend and use demonstration content.

Expected Output: Provide complete, separate code for "index.html", "styles.css", and "script.js". Include a clear page heading, a short introduction, four destination cards, a search box, category buttons for All, Beach, Nature, and Culture, a result count, and a message when no destinations match. Use a clean green-themed design suitable for a tourism guide.

Acceptance Criteria:

1. All four destination cards appear when the page loads.
2. Searching filters the cards by matching text.
3. Selecting a category displays only destinations in that category.
4. The All button displays every destination that matches the search.
5. A helpful message appears when no results match.
6. The layout remains readable on mobile and tablet screens.
7. The HTML, CSS, and JavaScript work together using the specified filenames.

Review the requirements carefully and provide the complete code for all three files.

Actual Copilot Output:

AI tool used: ChatGPT

Saved output: "outputs/task3-structured-prompt-index.html"

The actual generated code and response are preserved in the output file.

What Worked:

It all worked.

What Needs Improvement:

The design need to be more realistic

Next Action / Verification:

It improve but still needs more improvement

Task 4A — Few-Shot Prompting

Objective:

To determine whether providing examples helps the AI produce destination entries with consistent names, categories, descriptions, and filter-compatible values.

Exact Prompt:

Act as a frontend web developer working on the Marinduque Tourism Guide.

Follow the examples below to create destination entries in a consistent format.

Example 1:
Destination: Poctoy White Beach
Category: Beach
Description: Enjoy the white sand and relaxing coastal scenery.

Example 2:
Destination: Boac Cathedral
Category: Culture
Description: Explore a historic church and learn about local heritage.

Example 3:
Destination: Mt. Malindig
Category: Nature
Description: Discover mountain scenery and the natural environment.

Using the same format, create four additional demonstration destinations in Marinduque. Each entry must have a destination name, one category (Beach, Nature, or Culture), and a short description.

Then show how the four entries can be represented as destination cards in my existing HTML, CSS, and JavaScript project. Keep the category values compatible with the existing category filters. Do not add a backend, database, or external API. Explain which code needs to be added or changed.

Actual Copilot Output:

AI tool used: ChatGPT

Saved output: "outputs/task4a-few-shot-index.html"

The actual AI response and generated examples are preserved in the output file.

What Worked:

The generated entries followed the example format and used consistent categories.

What Needs Improvement:

Still needs to be realistic.

Next Action / Verification:

Thee four generated entries are added, the search and category filters work with the new cards.

Task 4B — Role Assignment

Objective:

To examine the existing tourism webpage from the perspective of a frontend accessibility reviewer.

Exact Prompt:

Act as a frontend accessibility reviewer.

Review my existing Marinduque Tourism Guide, a responsive tourism webpage for tourists, local residents, and students in Marinduque, Philippines.

Examine the provided HTML, CSS, and JavaScript. Focus on:

1. HTML semantics and heading structure.
2. Accessible labels for the search box and filter buttons.
3. Keyboard accessibility and visible focus indicators.
4. Text readability, color contrast, and mobile or tablet usability.
5. Whether the search and category filters remain usable.

Identify the three most important issues that are actually supported by the code. For each issue, explain why it matters and recommend a specific, minimal correction.

Do not rewrite the entire project or add new features. Preserve the current project scope. Provide corrected code snippets where necessary and give me a simple procedure for verifying each recommended correction. Do not claim that a change has been tested unless it has actually been tested.

Actual Copilot Output:

AI tool used: ChatGPT

Saved output: "outputs/task4b-role-assignment-index.html"

The actual review, recommendations, and code snippets are preserved in the output file.

What Worked:

The recommendation is important to my code.

What Needs Improvement:

Still needs to be realistic

Next Action / Verification:

Recommendations have been identified from the supplied code. They are not considered fixed or tested until the corrections are applied and the relevant checks are performed in the browser.

Task 5 — Structured Analysis and Refinement

Objective:

To analyze the actual tourism webpage, identify an implementation weakness, apply a targeted correction, and verify the result.

Exact Prompt:

Act as a frontend debugging and code-review specialist.

Analyze my existing Marinduque Tourism Guide. I will provide the current contents of "index.html", "styles.css", and "script.js".

Check the implementation against these requirements:

- Search filters destination cards by text.
- Category buttons filter by Beach, Nature, Culture, or All.
- The result count updates correctly.
- A no-results message appears when no cards match.
- The webpage remains usable on mobile and tablet screens.
- The HTML uses appropriate semantic elements and accessible labels.

Identify the two most important implementation issues that are supported by the code. If the code does not reveal two genuine issues, explain that instead of inventing problems.

For each issue, state the affected file, explain the cause briefly, and provide the smallest appropriate correction. Do not rewrite unrelated parts of the project.

After recommending a correction, provide a step-by-step test procedure with expected results. Clearly distinguish what you can determine from reading the code from what must be tested in the browser.

I will apply and test at least one correction and report the actual result.

Actual Copilot Output:

AI tool used: ChatGPT

Saved output: "outputs/task5-structured-analysis-index.html"

The actual analysis, recommended corrections, and test instructions are preserved in the output file.

What Worked:

[Describe the useful diagnosis or correction based on the actual AI response and your test.]

What Needs Improvement:

the ariel-label needs ro be ariel-pressed

Next Action / Verification:

Issue selected: ariel-label changed to ariel-pressed

File changed: [index.html, styles.css, or script.js.]

Correction applied: ariel-label changed to ariel-pressed

Test performed: run the program

Verification result: PASS

Task 6 — Compare and Submit

Technique: Zero-Shot Prompt    
Observation: The AI created a basic Marinduque Tourism Guide webpage using a simple instruction. It included destination cards, a search box, and category filters. However, some details and requirements needed to be improved.

Technique: Structured Prompt   
Observation: The AI produced a more organized result because the prompt included a role, task, context, constraints, expected output, and acceptance criteria. The instructions helped make the webpage more complete and easier to understand.                                                                  
Technique: Few-Shot Prompt     
Observation: Providing examples of destinations and their categories helped the AI follow the desired format. It suggested additional destinations that matched the examples, making it easier to expand the tourism guide consistently.                                                                         
Technique: Role Assignment     
Observation: Assigning the AI the role of a frontend developer helped focus its response on improving the webpage's design, functionality, and accessibility. The role provided clearer direction for the AI's suggestions.                                                           

Technique: Structured Analysis  
Observation: Reviewing the generated code helped identify an accessibility issue in the All filter button. Changing aria-label="true" to aria-pressed="true" corrected the initial button state. Testing was also needed to verify the search, filters, result count, no-results message, and responsive layout.

Final Reflection

In this laboratory activity, I developed the Marinduque Tourism Guide, a frontend prototype under the Tourism & Cultural Innovation sector. I experimented with different prompting techniques to improve the generated webpage.

Zero-shot prompting provided an initial implementation, while structured prompting allowed me to specify the project's users, features, constraints, and acceptance criteria. Few-shot prompting helped demonstrate a consistent format for destination entries. Role assignment allowed me to examine the interface from an accessibility perspective, while structured analysis helped me identify and address a technical issue.

This activity taught me that clear prompts can improve AI-generated code, but the results still need to be inspected and tested. The final version I selected was the one that best satisfied the project requirements based on my actual verification results.

[Add one specific example of a problem you encountered, the correction you made, and the result of your test.]